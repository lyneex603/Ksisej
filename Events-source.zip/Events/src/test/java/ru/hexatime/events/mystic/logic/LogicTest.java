package ru.hexatime.events.mystic.logic;

import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class LogicTest {

    private static List<String> pool(int n) {
        List<String> l = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            l.add("item" + i);
        }
        return l;
    }

    @Test
    void layoutCountsForBigPool() {
        for (int seed = 0; seed < 500; seed++) {
            List<LootLayout.Entry<String>> e = LootLayout.generate(pool(54), 54, 13, 14, 9, 700, 400, new Random(seed));
            long initial = e.stream().filter(x -> x.revealOffsetMs() == 0).count();
            assertTrue(initial == 13 || initial == 14, "initial=" + initial);
            assertEquals(initial + 9, e.size());
            assertTrue(e.size() == 22 || e.size() == 23);
        }
    }

    @Test
    void layoutSlotsAndItemsUnique() {
        for (int seed = 0; seed < 500; seed++) {
            List<LootLayout.Entry<String>> e = LootLayout.generate(pool(40), 54, 13, 14, 9, 700, 400, new Random(seed));
            Set<Integer> slots = new HashSet<>();
            Set<String> items = new HashSet<>();
            for (LootLayout.Entry<String> x : e) {
                assertTrue(x.slot() >= 0 && x.slot() < 54);
                assertTrue(slots.add(x.slot()), "slot duplicate");
                assertTrue(items.add(x.item()), "item duplicate");
            }
        }
    }

    @Test
    void layoutRevealTimes() {
        List<LootLayout.Entry<String>> e = LootLayout.generate(pool(54), 54, 13, 14, 9, 700, 400, new Random(1));
        List<Long> offs = e.stream().map(LootLayout.Entry::revealOffsetMs).filter(o -> o > 0).sorted().toList();
        assertEquals(List.of(700L, 1100L, 1500L, 1900L, 2300L, 2700L, 3100L, 3500L, 3900L), offs);
    }

    @Test
    void layoutSmallPools() {
        assertEquals(0, LootLayout.generate(pool(0), 54, 13, 14, 9, 700, 400, new Random(1)).size());
        assertEquals(1, LootLayout.generate(pool(1), 54, 13, 14, 9, 700, 400, new Random(1)).size());
        List<LootLayout.Entry<String>> e = LootLayout.generate(pool(10), 54, 13, 14, 9, 700, 400, new Random(1));
        assertEquals(10, e.size());
        assertTrue(e.stream().allMatch(x -> x.revealOffsetMs() == 0));
        // пул 16: 13-14 сразу, остальные 2-3 позже
        List<LootLayout.Entry<String>> f = LootLayout.generate(pool(16), 54, 13, 14, 9, 700, 400, new Random(2));
        assertEquals(16, f.size());
    }

    @Test
    void layoutIsRandomPerCall() {
        Set<List<Integer>> layouts = new HashSet<>();
        for (int seed = 0; seed < 20; seed++) {
            List<Integer> s = LootLayout.generate(pool(54), 54, 13, 14, 9, 700, 400, new Random(seed))
                    .stream().map(LootLayout.Entry::slot).toList();
            layouts.add(s);
        }
        assertTrue(layouts.size() > 15);
    }

    private static LootBook<String> book() {
        List<LootLayout.Entry<String>> e = List.of(
                new LootLayout.Entry<>(3, "a", 0), new LootLayout.Entry<>(7, "b", 700));
        return new LootBook<>(e);
    }

    @Test
    void bookStateMachine() {
        LootBook<String> b = book();
        assertNull(b.itemAt(3));          // ещё не показан
        assertFalse(b.reserve(3));
        assertTrue(b.reveal(3));
        assertEquals("a", b.itemAt(3));
        assertTrue(b.reserve(3));
        assertNull(b.itemAt(3));          // занят
        assertFalse(b.reserve(3));        // второй не получит
        b.release(3);                     // выдача не удалась (полный инвентарь)
        assertEquals("a", b.itemAt(3));
        assertTrue(b.reserve(3));
        assertTrue(b.commit(3));
        assertFalse(b.commit(3));
        assertFalse(b.isComplete());      // "b" ещё не показан и не забран
        b.reveal(7);
        b.reserve(7);
        b.commit(7);
        assertTrue(b.isComplete());
        assertEquals(0, b.remaining());
    }

    @Test
    void bookRestoreClaimed() {
        LootBook<String> b = book();
        b.restoreClaimed(3);
        b.reveal(3);
        assertNull(b.itemAt(3));
        assertEquals(1, b.remaining());
    }

    @Test
    void onlyOneThreadReservesSameItem() throws Exception {
        for (int round = 0; round < 200; round++) {
            LootBook<String> b = book();
            b.reveal(3);
            int threads = 16;
            ExecutorService ex = Executors.newFixedThreadPool(threads);
            CountDownLatch go = new CountDownLatch(1);
            AtomicInteger winners = new AtomicInteger();
            List<Future<?>> fs = new ArrayList<>();
            for (int i = 0; i < threads; i++) {
                fs.add(ex.submit(() -> {
                    go.await();
                    if (b.reserve(3)) {
                        winners.incrementAndGet();
                    }
                    return null;
                }));
            }
            go.countDown();
            for (Future<?> f : fs) {
                f.get();
            }
            ex.shutdown();
            assertEquals(1, winners.get());
        }
    }

    @Test
    void cooldown() {
        ClaimCooldown c = new ClaimCooldown();
        UUID u = UUID.randomUUID();
        long t0 = 1_000_000_000L;
        assertTrue(c.ready(u, t0, 300));
        c.mark(u, t0);
        assertFalse(c.ready(u, t0 + 299_000_000L, 300));
        assertTrue(c.ready(u, t0 + 300_000_000L, 300));
        assertTrue(c.ready(UUID.randomUUID(), t0, 300));   // у другого игрока свой кулдаун
        c.forget(u);
        assertTrue(c.ready(u, t0 + 1, 300));
    }

    @Test
    void zone13x13() {
        ZoneBox z = new ZoneBox(100, -50, 6);
        assertEquals(13, z.size());
        assertTrue(z.contains(100, -50));
        assertTrue(z.contains(94, -56));
        assertTrue(z.contains(106, -44));
        assertFalse(z.contains(93, -50));
        assertFalse(z.contains(107, -50));
        assertFalse(z.contains(100, -43));
        int inside = 0;
        for (int x = 80; x < 120; x++) {
            for (int zz = -70; zz < -30; zz++) {
                if (z.contains(x, zz)) {
                    inside++;
                }
            }
        }
        assertEquals(169, inside);
    }

    @Test
    void zoneIntersections() {
        ZoneBox a = new ZoneBox(0, 0, 6);
        assertTrue(a.intersects(new ZoneBox(12, 0, 6), 0));
        assertFalse(a.intersects(new ZoneBox(13, 0, 6), 0));
        assertTrue(a.intersects(new ZoneBox(13, 0, 6), 1));
        assertFalse(a.intersects(new ZoneBox(100, 100, 6), 5));
    }

    @Test
    void timeFormat() {
        assertEquals("0:00", TimeFormat.format(0));
        assertEquals("0:00", TimeFormat.format(-5));
        assertEquals("0:01", TimeFormat.format(1));
        assertEquals("1:15", TimeFormat.format(75_000));
        assertEquals("59:59", TimeFormat.format(3_599_000));
        assertEquals("1:02:05", TimeFormat.format(3_725_000));
    }

    @Test
    void spawnCoordinatesInRange() {
        Random r = new Random(5);
        boolean sawMin = false, sawMax = false;
        for (int i = 0; i < 200_000; i++) {
            int v = SpawnMath.between(r, -700, 1300);
            assertTrue(v >= -700 && v <= 1300);
            sawMin |= v == -700;
            sawMax |= v == 1300;
        }
        assertTrue(sawMin && sawMax);
        assertEquals(5, SpawnMath.between(r, 5, 5));
        int swapped = SpawnMath.between(r, 10, -10);
        assertTrue(swapped >= -10 && swapped <= 10);
    }

    @Test
    void randomMysticDistribution40_30_20_10() {
        Map<String, Integer> w = new LinkedHashMap<>();
        w.put("common", 40);
        w.put("rare", 30);
        w.put("epic", 20);
        w.put("legendary", 10);
        Random r = new Random(123);
        int n = 200_000;
        Map<String, Integer> cnt = new HashMap<>();
        for (int i = 0; i < n; i++) {
            cnt.merge(WeightedPicker.pick(w, r), 1, Integer::sum);
        }
        assertTrue(Math.abs(cnt.get("common") / (double) n - 0.40) < 0.01, "common " + cnt);
        assertTrue(Math.abs(cnt.get("rare") / (double) n - 0.30) < 0.01, "rare " + cnt);
        assertTrue(Math.abs(cnt.get("epic") / (double) n - 0.20) < 0.01, "epic " + cnt);
        assertTrue(Math.abs(cnt.get("legendary") / (double) n - 0.10) < 0.01, "legendary " + cnt);
        // если у легендарного пустое хранилище (вес 0), остальные перенормируются: 40/30/20 из 90
        w.put("legendary", 0);
        cnt.clear();
        for (int i = 0; i < n; i++) {
            cnt.merge(WeightedPicker.pick(w, r), 1, Integer::sum);
        }
        assertNull(cnt.get("legendary"));
        assertTrue(Math.abs(cnt.get("common") / (double) n - 40.0 / 90) < 0.01);
    }

    @Test
    void weightedPicker() {
        Map<String, Integer> w = new LinkedHashMap<>();
        w.put("a", 0);
        w.put("b", 3);
        w.put("c", 1);
        Random r = new Random(9);
        Map<String, Integer> cnt = new HashMap<>();
        for (int i = 0; i < 40_000; i++) {
            cnt.merge(WeightedPicker.pick(w, r), 1, Integer::sum);
        }
        assertNull(cnt.get("a"));
        double ratio = cnt.get("b") / (double) cnt.get("c");
        assertTrue(ratio > 2.7 && ratio < 3.3, "ratio=" + ratio);
        assertNull(WeightedPicker.pick(Map.of("x", 0), r));
        assertNull(WeightedPicker.pick(Map.of(), r));
    }
}
