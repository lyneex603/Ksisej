package ru.hexatime.events;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import ru.hexatime.events.core.EventRegistry;
import ru.hexatime.events.core.EventsCommand;
import ru.hexatime.events.core.Messages;
import ru.hexatime.events.core.gui.MenuListener;
import ru.hexatime.events.mystic.MysticModule;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;

/** Events — EventsCore (регистрация событий, команды, меню, сохранение) + модуль Mystic. */
public final class EventsPlugin extends JavaPlugin {

    private EventRegistry registry;
    private Messages messages;
    private ExecutorService io;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        io = Executors.newSingleThreadExecutor(r -> new Thread(r, "Events-IO"));
        messages = new Messages(this);
        registry = new EventRegistry(this);
        registry.register(new MysticModule(this));

        PluginCommand cmd = getCommand("event");
        if (cmd == null) {
            getLogger().severe("Команда /event не найдена в plugin.yml — плагин отключается");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        EventsCommand handler = new EventsCommand(this, registry);
        cmd.setExecutor(handler);
        cmd.setTabCompleter(handler);
        getServer().getPluginManager().registerEvents(new MenuListener(), this);
        registry.enableAll();
    }

    @Override
    public void onDisable() {
        if (registry != null) {
            registry.disableAll();
        }
        if (io != null) {
            io.shutdown();
            try {
                if (!io.awaitTermination(10, TimeUnit.SECONDS)) {
                    getLogger().warning("Не все данные успели записаться на диск за 10 секунд");
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void reloadAll() {
        reloadConfig();
        registry.reloadAll();
    }

    public Messages messages() {
        return messages;
    }

    /** Фоновая запись на диск (один поток, порядок записей сохраняется). */
    public void io(Runnable task) {
        try {
            io.execute(task);
        } catch (RejectedExecutionException e) {
            task.run();
        }
    }
}
