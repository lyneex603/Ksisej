package ru.hexatime.events.mystic;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.Map;

final class InventoryUtil {

    private InventoryUtil() {
    }

    /** Поместится ли предмет целиком в основной инвентарь (хотбар + 27 слотов), без брони и второй руки. */
    static boolean fits(PlayerInventory inv, ItemStack item) {
        int need = item.getAmount();
        int max = item.getMaxStackSize();
        for (ItemStack s : inv.getStorageContents()) {
            if (s == null || s.getType().isAir()) {
                need -= max;
            } else if (s.isSimilar(item)) {
                need -= Math.max(0, max - s.getAmount());
            }
            if (need <= 0) {
                return true;
            }
        }
        return false;
    }

    /** Выдаёт предмет целиком; если часть не влезла — откатывает уже выданное и возвращает false. */
    static boolean give(Player p, ItemStack item) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(item.clone());
        if (left.isEmpty()) {
            return true;
        }
        int notAdded = left.values().stream().mapToInt(ItemStack::getAmount).sum();
        int added = item.getAmount() - notAdded;
        if (added > 0) {
            ItemStack rollback = item.clone();
            rollback.setAmount(added);
            p.getInventory().removeItem(rollback);
        }
        return false;
    }
}
