package ru.hexatime.events.mystic;

import org.bukkit.entity.ArmorStand;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import ru.hexatime.events.mystic.logic.LootBook;
import ru.hexatime.events.mystic.logic.ZoneBox;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Один появившийся Mystic: место, состояние, награды. Живёт на главном потоке. */
final class MysticSession {

    enum State { WAITING, OPEN }

    final UUID id;
    final Rarity rarity;
    final UUID worldId;
    final int x, y, z;
    final boolean fromGive;
    final ZoneBox zone;

    State state = State.WAITING;
    long openAtMs;
    long openedAtMs;
    long lootStartedAtMs;
    long completedAtMs;

    LootBook<ItemStack> book;
    Inventory inventory;
    final List<BukkitTask> revealTasks = new ArrayList<>();
    ArmorStand titleStand;
    ArmorStand timeStand;
    String lastTimeText;

    MysticSession(UUID id, Rarity rarity, UUID worldId, int x, int y, int z, boolean fromGive, int radius) {
        this.id = id;
        this.rarity = rarity;
        this.worldId = worldId;
        this.x = x;
        this.y = y;
        this.z = z;
        this.fromGive = fromGive;
        this.zone = new ZoneBox(x, z, radius);
    }
}
