package ru.hexatime.events.mystic;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import ru.hexatime.events.core.Messages;
import ru.hexatime.events.core.gui.MenuHolder;

import java.util.List;
import java.util.UUID;

/**
 * Редактор хранилища наград одной редкости: обычный сундук на 54 слота, администратор свободно
 * кладёт/забирает/заменяет предметы. Дубликат (одинаковый тип, зачарования, название, мета) через тик
 * убирается из меню и возвращается администратору. При закрытии содержимое сохраняется.
 */
final class AdminRewardMenu extends MenuHolder {

    static final String PERM = "events.admin.rewards";

    private final MysticModule module;
    private final Rarity rarity;
    private final UUID adminId;
    private boolean closed;

    AdminRewardMenu(MysticModule module, Rarity rarity, Player admin) {
        this.module = module;
        this.rarity = rarity;
        this.adminId = admin.getUniqueId();
        createInventory(RewardStore.SIZE, Component.text("Награды: ").append(rarity.component()))
                .setContents(module.store().slots(rarity));
    }

    @Override
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !p.hasPermission(PERM)) {
            e.setCancelled(true);
            return;
        }
        scheduleCheck(p);
    }

    @Override
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !p.hasPermission(PERM)) {
            e.setCancelled(true);
            return;
        }
        scheduleCheck(p);
    }

    private void scheduleCheck(Player p) {
        Bukkit.getScheduler().runTask(module.plugin(), () -> dedupe(p));
    }

    private void dedupe(Player p) {
        if (closed) {
            return;
        }
        ItemStack[] contents = getInventory().getContents();
        List<ItemStack> removed = ItemUniq.removeDuplicates(contents);
        if (removed.isEmpty()) {
            return;
        }
        getInventory().setContents(contents);
        for (ItemStack it : removed) {
            p.getInventory().addItem(it).values()
                    .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
        }
        module.plugin().messages().send(p, "duplicate-removed");
    }

    @Override
    public void onClose(InventoryCloseEvent e) {
        if (closed) {
            return;
        }
        closed = true;
        if (e.getPlayer() instanceof Player p) {
            ItemStack[] contents = getInventory().getContents();
            List<ItemStack> removed = ItemUniq.removeDuplicates(contents);
            for (ItemStack it : removed) {
                p.getInventory().addItem(it).values()
                        .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
            }
            module.saveRewards(rarity, contents);
            module.releaseEditor(rarity, adminId);
            int count = module.store().count(rarity);
            module.plugin().messages().send(p, "rewards-saved",
                    Messages.comp("rarity", rarity.component()), Messages.text("count", String.valueOf(count)));
        } else {
            module.saveRewards(rarity, getInventory().getContents());
            module.releaseEditor(rarity, adminId);
        }
    }
}
