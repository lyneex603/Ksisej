package ru.hexatime.events.core.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Базовый класс меню плагина. По умолчанию меню «только для просмотра»: все клики и перетаскивания отменяются. */
public abstract class MenuHolder implements InventoryHolder {

    private Inventory inventory;

    protected final Inventory createInventory(int size, Component title) {
        this.inventory = Bukkit.createInventory(this, size, title);
        return inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void onClick(InventoryClickEvent e) {
        e.setCancelled(true);
    }

    public void onDrag(InventoryDragEvent e) {
        e.setCancelled(true);
    }

    public void onClose(InventoryCloseEvent e) {
    }
}
