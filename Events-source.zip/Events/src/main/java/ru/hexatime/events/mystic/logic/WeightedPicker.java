package ru.hexatime.events.mystic.logic;

import java.util.Map;
import java.util.Random;

public final class WeightedPicker {

    private WeightedPicker() {
    }

    /** Выбор по весам; веса ≤ 0 игнорируются; null, если выбирать не из чего. */
    public static <T> T pick(Map<T, Integer> weights, Random rnd) {
        long sum = 0;
        for (int w : weights.values()) {
            if (w > 0) {
                sum += w;
            }
        }
        if (sum <= 0) {
            return null;
        }
        long r = (long) (rnd.nextDouble() * sum);
        for (Map.Entry<T, Integer> e : weights.entrySet()) {
            if (e.getValue() <= 0) {
                continue;
            }
            r -= e.getValue();
            if (r < 0) {
                return e.getKey();
            }
        }
        return null;
    }
}
