package ru.hexatime.events.mystic;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;

/** Открытие сундука Mystic (вместо обычного эндер-сундука), установка выданного Mystic, очистка данных вышедшего игрока. */
final class MysticListener implements Listener {

    private final MysticModule module;

    MysticListener(MysticModule module) {
        this.module = module;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Block b = e.getClickedBlock();
        if (b == null || b.getType() != Material.ENDER_CHEST) {
            return;
        }
        MysticSession s = module.sessionAt(b);
        if (s == null) {
            return;
        }
        e.setCancelled(true);   // обычный эндер-сундук не открываем
        if (e.getHand() == EquipmentSlot.HAND) {
            module.onChestInteract(e.getPlayer(), s);
        }
    }

    /** Выданный через /event give Mystic: при установке превращается в открытый Mystic своей редкости. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (module.isRandomItem(e.getItemInHand())) {
            if (!module.createGivenRandom(p, e.getBlockPlaced())) {
                e.setCancelled(true);
            }
            return;
        }
        Rarity r = module.rarityOfItem(e.getItemInHand());
        if (r == null) {
            return;
        }
        if (!module.createGiven(p, e.getBlockPlaced(), r)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        module.forget(e.getPlayer().getUniqueId());
    }
}
