package ru.hexatime.events.mystic;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Уникальность предметов: ItemStack#isSimilar сравнивает тип, зачарования, название и всю остальную мету (кроме количества). */
final class ItemUniq {

    private ItemUniq() {
    }

    /** Убирает из массива воздух и дубликаты (остаётся первый по порядку слотов). Возвращает убранные дубликаты. */
    static List<ItemStack> removeDuplicates(ItemStack[] contents) {
        List<ItemStack> removed = new ArrayList<>();
        for (int i = 0; i < contents.length; i++) {
            ItemStack a = contents[i];
            if (a == null || a.getType().isAir()) {
                contents[i] = null;
                continue;
            }
            for (int j = 0; j < i; j++) {
                ItemStack b = contents[j];
                if (b != null && b.isSimilar(a)) {
                    removed.add(a);
                    contents[i] = null;
                    break;
                }
            }
        }
        return removed;
    }
}
