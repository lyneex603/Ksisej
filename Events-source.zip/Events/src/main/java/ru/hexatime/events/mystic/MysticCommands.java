package ru.hexatime.events.mystic;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.hexatime.events.core.Messages;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Административные подкоманды Mystic: give, rewards, start, stop. */
final class MysticCommands {

    static final List<String> SUBS = List.of("give", "rewards", "start", "stop");
    private static final Map<String, String> PERMS = Map.of(
            "give", "events.admin.give", "rewards", "events.admin.rewards",
            "start", "events.admin.start", "stop", "events.admin.stop");

    private final MysticModule module;

    MysticCommands(MysticModule module) {
        this.module = module;
    }

    private Messages msg() {
        return module.plugin().messages();
    }

    boolean canUse(CommandSender s, String sub) {
        String perm = PERMS.get(sub);
        return perm != null && s.hasPermission(perm);
    }

    boolean handle(CommandSender sender, String sub, String[] args) {
        switch (sub) {
            case "give" -> give(sender, args);
            case "rewards" -> rewards(sender, args);
            case "start" -> {
                if (module.startNow()) {
                    msg().send(sender, "started");
                } else {
                    msg().send(sender, "start-failed");
                }
            }
            case "stop" -> {
                module.stopActive();
                msg().send(sender, "stopped");
            }
            default -> {
                return false;
            }
        }
        return true;
    }

    private void give(CommandSender sender, String[] args) {
        if (args.length < 2) {
            msg().send(sender, "usage-give");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            msg().send(sender, "player-not-found", Messages.text("player", args[0]));
            return;
        }
        boolean random = args[1].equalsIgnoreCase(MysticModule.RANDOM_KIND) || args[1].equalsIgnoreCase("случайный");
        Rarity r = random ? null : Rarity.parse(args[1]);
        if (!random && r == null) {
            msg().send(sender, "bad-rarity", Messages.text("rarities", String.join(", ", Rarity.ids()) + ", random"));
            return;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                amount = -1;
            }
            if (amount < 1 || amount > 64) {
                msg().send(sender, "bad-amount");
                return;
            }
        }
        target.getInventory().addItem(random ? module.createRandomItem(amount) : module.createMysticItem(r, amount)).values()
                .forEach(left -> target.getWorld().dropItemNaturally(target.getLocation(), left));
        msg().send(sender, "given", Messages.text("amount", String.valueOf(amount)),
                Messages.comp("rarity", random ? MysticModule.randomItemName() : r.component()),
                Messages.text("player", target.getName()));
    }

    private void rewards(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            msg().send(sender, "player-only");
            return;
        }
        if (args.length < 1) {
            msg().send(sender, "usage-rewards");
            return;
        }
        Rarity r = Rarity.parse(args[0]);
        if (r == null) {
            msg().send(sender, "bad-rarity", Messages.text("rarities", String.join(", ", Rarity.ids())));
            return;
        }
        module.openEditor(p, r);
    }

    List<String> complete(CommandSender sender, String sub, String[] args) {
        List<String> out = new ArrayList<>();
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "give" -> {
                if (args.length == 1) {
                    Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                } else if (args.length == 2) {
                    out.addAll(Rarity.ids());
                    out.add("random");
                } else if (args.length == 3) {
                    out.addAll(List.of("1", "5", "10", "64"));
                }
            }
            case "rewards" -> {
                if (args.length == 1) {
                    out.addAll(Rarity.ids());
                }
            }
            default -> {
            }
        }
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
