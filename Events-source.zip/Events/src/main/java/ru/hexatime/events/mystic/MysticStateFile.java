package ru.hexatime.events.mystic;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import ru.hexatime.events.EventsPlugin;
import ru.hexatime.events.core.util.FileUtil;
import ru.hexatime.events.mystic.logic.LootBook;
import ru.hexatime.events.mystic.logic.LootLayout;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Состояние событий на диске (plugins/Events/data/mystic.yml): таймеры (абсолютное время), расположение,
 * выбранные награды и какие из них уже забраны. Время хранится в мс Unix, поэтому таймер идёт и пока сервер выключен.
 */
final class MysticStateFile {

    record Loaded(boolean autoSpawn, long retryAtMs, List<MysticSession> sessions) {
    }

    private final EventsPlugin plugin;
    private final File file;

    MysticStateFile(EventsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data/mystic.yml");
    }

    /** Собирает снимок на главном потоке, записывает в фоне (очередь одного потока — порядок записей сохраняется). */
    void saveAsync(boolean autoSpawn, long retryAtMs, List<MysticSession> sessions) {
        String data = serialize(autoSpawn, retryAtMs, sessions);
        plugin.io(() -> {
            try {
                FileUtil.writeAtomic(file, data);
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Не удалось сохранить состояние Mystic", e);
            }
        });
    }

    private String serialize(boolean autoSpawn, long retryAtMs, List<MysticSession> sessions) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("auto-spawn", autoSpawn);
        y.set("retry-at", retryAtMs);
        for (MysticSession s : sessions) {
            String p = "sessions." + s.id + ".";
            y.set(p + "rarity", s.rarity.id());
            y.set(p + "world", s.worldId.toString());
            y.set(p + "x", s.x);
            y.set(p + "y", s.y);
            y.set(p + "z", s.z);
            y.set(p + "radius", s.zone.radius());
            y.set(p + "from-give", s.fromGive);
            y.set(p + "state", s.state.name());
            y.set(p + "open-at", s.openAtMs);
            y.set(p + "opened-at", s.openedAtMs);
            y.set(p + "loot-started-at", s.lootStartedAtMs);
            y.set(p + "completed-at", s.completedAtMs);
            if (s.book != null) {
                List<Map<String, Object>> list = new ArrayList<>();
                for (LootBook.View<ItemStack> v : s.book.snapshot()) {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("slot", v.slot());
                    m.put("item", Base64.getEncoder().encodeToString(v.item().serializeAsBytes()));
                    m.put("offset", v.revealOffsetMs());
                    m.put("claimed", v.status() == LootBook.Status.CLAIMED);
                    list.add(m);
                }
                y.set(p + "rewards", list);
            }
        }
        return y.saveToString();
    }

    Loaded load() {
        List<MysticSession> out = new ArrayList<>();
        if (!file.exists()) {
            return new Loaded(true, 0L, out);
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection secs = y.getConfigurationSection("sessions");
        if (secs != null) {
            for (String key : secs.getKeys(false)) {
                try {
                    MysticSession s = parse(key, secs.getConfigurationSection(key));
                    if (s != null) {
                        out.add(s);
                    }
                } catch (Exception e) {
                    plugin.getLogger().log(Level.WARNING, "Пропущена повреждённая запись Mystic " + key, e);
                }
            }
        }
        return new Loaded(y.getBoolean("auto-spawn", true), y.getLong("retry-at", 0L), out);
    }

    private MysticSession parse(String key, ConfigurationSection c) {
        Rarity rarity = Rarity.parse(c.getString("rarity"));
        if (rarity == null) {
            return null;
        }
        MysticSession s = new MysticSession(UUID.fromString(key), rarity, UUID.fromString(c.getString("world", "")),
                c.getInt("x"), c.getInt("y"), c.getInt("z"), c.getBoolean("from-give"), Math.max(1, c.getInt("radius", 6)));
        s.state = MysticSession.State.valueOf(c.getString("state", "WAITING"));
        s.openAtMs = c.getLong("open-at");
        s.openedAtMs = c.getLong("opened-at");
        s.lootStartedAtMs = c.getLong("loot-started-at");
        s.completedAtMs = c.getLong("completed-at");

        List<Map<?, ?>> rewards = c.getMapList("rewards");
        if (!rewards.isEmpty()) {
            List<LootLayout.Entry<ItemStack>> entries = new ArrayList<>();
            List<Integer> claimed = new ArrayList<>();
            for (Map<?, ?> m : rewards) {
                int slot = ((Number) m.get("slot")).intValue();
                ItemStack item = ItemStack.deserializeBytes(Base64.getDecoder().decode(String.valueOf(m.get("item"))));
                long offset = ((Number) m.get("offset")).longValue();
                entries.add(new LootLayout.Entry<>(slot, item, offset));
                if (Boolean.TRUE.equals(m.get("claimed"))) {
                    claimed.add(slot);
                }
            }
            s.book = new LootBook<>(entries);
            claimed.forEach(s.book::restoreClaimed);
        }
        if (s.state == MysticSession.State.OPEN && s.book == null) {
            s.state = MysticSession.State.WAITING;   // повреждённые данные: откроется заново
            s.openAtMs = System.currentTimeMillis();
        }
        return s;
    }
}
