package ru.hexatime.events.core.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import ru.hexatime.events.core.EventModule;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Главное меню /event: по одной иконке на каждое включённое событие. */
public final class EventsMenu extends MenuHolder {

    private final JavaPlugin plugin;
    private final Map<Integer, EventModule> bySlot = new HashMap<>();

    public EventsMenu(JavaPlugin plugin, List<EventModule> modules) {
        this.plugin = plugin;
        int rows = modules.size() <= 7 ? 3 : Math.min(6, 2 + (modules.size() + 6) / 7);
        Inventory inv = createInventory(rows * 9, Component.text("События"));
        for (int i = 0; i < modules.size() && i < 28; i++) {
            EventModule m = modules.get(i);
            int slot = modules.size() == 1 ? 13 : 9 * (1 + i / 7) + 1 + i % 7;
            ItemStack icon = new ItemStack(m.iconMaterial());
            ItemMeta meta = icon.getItemMeta();
            meta.displayName(m.displayName().decoration(TextDecoration.ITALIC, false));
            icon.setItemMeta(meta);
            inv.setItem(slot, icon);
            bySlot.put(slot, m);
        }
    }

    @Override
    public void onClick(InventoryClickEvent e) {
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p) || !getInventory().equals(e.getClickedInventory())) {
            return;
        }
        EventModule m = bySlot.get(e.getSlot());
        if (m != null && m.isEnabled()) {
            // открывать другой инвентарь прямо из обработчика клика небезопасно — откладываем на тик
            Bukkit.getScheduler().runTask(plugin, () -> m.openMenu(p));
        }
    }
}
