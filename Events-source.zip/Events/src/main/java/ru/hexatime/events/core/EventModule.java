package ru.hexatime.events.core;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collection;
import java.util.List;

/**
 * Контракт модуля события. EventsCore ничего не знает о конкретных событиях: он регистрирует модули,
 * рисует главное меню, маршрутизирует команды и проверяет права. Всё остальное (GUI, награды, таймеры,
 * координаты, защита, завершение, конфигурация) модуль делает сам.
 */
public interface EventModule {

    /** Короткий id, он же подкоманда: /event <id>. */
    String id();

    Component displayName();

    Material iconMaterial();

    boolean isEnabled();

    void enable();

    void disable();

    /** Вызывается после /event reload (конфиг уже перечитан). */
    void reload();

    void openMenu(Player player);

    /** Строка статуса для /event time или null, если у события нет таймера. */
    default Component timeStatus() {
        return null;
    }

    /** Все подкоманды модуля (для маршрутизации /event <sub>). */
    default Collection<String> subcommands() {
        return List.of();
    }

    default boolean canUse(CommandSender sender, String sub) {
        return true;
    }

    /** true, если подкоманда распознана (даже при ошибке аргументов — сообщение уже отправлено). */
    default boolean handle(CommandSender sender, String sub, String[] args) {
        return false;
    }

    default List<String> complete(CommandSender sender, String sub, String[] args) {
        return List.of();
    }
}
