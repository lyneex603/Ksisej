package ru.hexatime.events.mystic.logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Общий для всех игроков учёт наград одного Mystic. Все операции атомарны (synchronized):
 * награду нельзя зарезервировать/забрать дважды.
 * Жизненный цикл: HIDDEN → VISIBLE → RESERVED → CLAIMED (при неудачной выдаче RESERVED → VISIBLE).
 */
public final class LootBook<T> {

    public enum Status { HIDDEN, VISIBLE, RESERVED, CLAIMED }

    public record View<T>(int slot, T item, long revealOffsetMs, Status status) {
    }

    private static final class Cell<T> {
        final int slot;
        final T item;
        final long offset;
        Status status = Status.HIDDEN;

        Cell(int slot, T item, long offset) {
            this.slot = slot;
            this.item = item;
            this.offset = offset;
        }
    }

    private final List<Cell<T>> cells = new ArrayList<>();
    private final Map<Integer, Cell<T>> bySlot = new HashMap<>();

    public LootBook(List<LootLayout.Entry<T>> entries) {
        for (LootLayout.Entry<T> e : entries) {
            Cell<T> c = new Cell<>(e.slot(), e.item(), e.revealOffsetMs());
            if (bySlot.putIfAbsent(e.slot(), c) != null) {
                throw new IllegalArgumentException("Два предмета в одном слоте: " + e.slot());
            }
            cells.add(c);
        }
    }

    public synchronized boolean reveal(int slot) {
        Cell<T> c = bySlot.get(slot);
        if (c == null || c.status != Status.HIDDEN) {
            return false;
        }
        c.status = Status.VISIBLE;
        return true;
    }

    /** Предмет, который сейчас можно забрать (виден и не занят), иначе null. */
    public synchronized T itemAt(int slot) {
        Cell<T> c = bySlot.get(slot);
        return c != null && c.status == Status.VISIBLE ? c.item : null;
    }

    /** Атомарно закрепляет награду за одним игроком. true получает ровно один вызывающий. */
    public synchronized boolean reserve(int slot) {
        Cell<T> c = bySlot.get(slot);
        if (c == null || c.status != Status.VISIBLE) {
            return false;
        }
        c.status = Status.RESERVED;
        return true;
    }

    /** Выдача не удалась — награда снова доступна. */
    public synchronized void release(int slot) {
        Cell<T> c = bySlot.get(slot);
        if (c != null && c.status == Status.RESERVED) {
            c.status = Status.VISIBLE;
        }
    }

    /** Выдача удалась — награда окончательно забрана. */
    public synchronized boolean commit(int slot) {
        Cell<T> c = bySlot.get(slot);
        if (c == null || c.status != Status.RESERVED) {
            return false;
        }
        c.status = Status.CLAIMED;
        return true;
    }

    /** Восстановление состояния после рестарта. */
    public synchronized void restoreClaimed(int slot) {
        Cell<T> c = bySlot.get(slot);
        if (c != null) {
            c.status = Status.CLAIMED;
        }
    }

    /** Все награды (включая ещё не показанные) забраны. */
    public synchronized boolean isComplete() {
        for (Cell<T> c : cells) {
            if (c.status != Status.CLAIMED) {
                return false;
            }
        }
        return !cells.isEmpty();
    }

    public synchronized int remaining() {
        int n = 0;
        for (Cell<T> c : cells) {
            if (c.status != Status.CLAIMED) {
                n++;
            }
        }
        return n;
    }

    public synchronized List<View<T>> snapshot() {
        List<View<T>> out = new ArrayList<>(cells.size());
        for (Cell<T> c : cells) {
            out.add(new View<>(c.slot, c.item, c.offset, c.status));
        }
        return out;
    }
}
