package ru.hexatime.events.mystic;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import ru.hexatime.events.core.gui.MenuHolder;

/** GUI редкости для игроков: награды хранилища только для просмотра (клики отменяются базовым классом). */
final class RarityViewMenu extends MenuHolder {

    RarityViewMenu(MysticModule module, Rarity rarity) {
        createInventory(RewardStore.SIZE,
                rarity.component().append(Component.text(" — награды", NamedTextColor.GRAY)))
                .setContents(module.store().slots(rarity));
    }
}
