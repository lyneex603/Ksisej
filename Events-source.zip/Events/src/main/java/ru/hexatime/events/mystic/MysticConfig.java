package ru.hexatime.events.mystic;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumMap;
import java.util.Map;

/** Все числа Mystic берутся из config.yml (раздел mystic). */
public final class MysticConfig {

    public final boolean enabled;
    public final String worldName;
    public final long intervalMs;
    public final long retryDelayMs;
    public final int minX, maxX, minZ, maxZ;
    public final int attempts;
    public final int minDistance;
    public final int maxHeightDiff;
    public final int radius;
    public final long despawnAfterLootMs;
    public final long maxOpenLifetimeMs;
    public final long claimCooldownMs;
    public final int initialMin, initialMax, additional;
    public final long firstDelayMs, stepMs;
    public final Map<Rarity, Integer> weights = new EnumMap<>(Rarity.class);
    /** Шансы редкостей у «Случайного Mystic» (предмет random). По умолчанию 40/30/20/10. */
    public final Map<Rarity, Integer> randomWeights = new EnumMap<>(Rarity.class);
    public final String holoTitle, holoOpenText, holoClosingText;
    public final double holoHeight;
    public final long tickTicks;

    private MysticConfig(FileConfiguration c) {
        String p = "mystic.";
        enabled = c.getBoolean(p + "enabled", true);
        worldName = c.getString(p + "world", "world");
        intervalMs = Math.max(1, c.getLong(p + "interval-minutes", 60)) * 60_000L;
        retryDelayMs = Math.max(5, c.getLong(p + "retry-delay-seconds", 60)) * 1000L;
        int x1 = c.getInt(p + "coordinates.min-x", -700), x2 = c.getInt(p + "coordinates.max-x", 1300);
        int z1 = c.getInt(p + "coordinates.min-z", -700), z2 = c.getInt(p + "coordinates.max-z", 1300);
        minX = Math.min(x1, x2);
        maxX = Math.max(x1, x2);
        minZ = Math.min(z1, z2);
        maxZ = Math.max(z1, z2);
        attempts = Math.max(1, c.getInt(p + "spawn-attempts", 40));
        minDistance = Math.max(0, c.getInt(p + "min-distance-between-mystics", 100));
        maxHeightDiff = Math.max(0, c.getInt(p + "max-height-difference", 10));
        radius = Math.max(1, c.getInt(p + "protection-radius", 6));
        despawnAfterLootMs = Math.max(0, c.getLong(p + "despawn-after-loot-seconds", 100)) * 1000L;
        maxOpenLifetimeMs = Math.max(0, c.getLong(p + "max-open-lifetime-seconds", 1800)) * 1000L;
        claimCooldownMs = Math.max(0, c.getLong(p + "claim-cooldown-ms", 300));
        int lo = c.getInt(p + "rewards.initial-min", 13), hi = c.getInt(p + "rewards.initial-max", 14);
        initialMin = Math.max(1, Math.min(lo, hi));
        initialMax = Math.max(initialMin, Math.max(lo, hi));
        additional = Math.max(0, c.getInt(p + "rewards.additional", 9));
        firstDelayMs = Math.max(50, c.getLong(p + "rewards.first-delay-ms", 700));
        stepMs = Math.max(50, c.getLong(p + "rewards.step-ms", 400));
        for (Rarity r : Rarity.values()) {
            weights.put(r, Math.max(0, c.getInt(p + "rarity-weights." + r.id(), 1)));
        }
        int[] randomDefaults = {40, 30, 20, 10};
        for (Rarity r : Rarity.values()) {
            randomWeights.put(r, Math.max(0, c.getInt(p + "random-weights." + r.id(), randomDefaults[r.ordinal()])));
        }
        holoTitle = c.getString(p + "hologram.title", "MYSTIC");
        holoOpenText = c.getString(p + "hologram.open-text", "Открыт");
        holoClosingText = c.getString(p + "hologram.closing-text", "Исчезнет через %time%");
        holoHeight = c.getDouble(p + "hologram.height", 1.4);
        tickTicks = Math.max(10, c.getLong(p + "tick-interval-ticks", 20));
    }

    public static MysticConfig load(FileConfiguration c) {
        return new MysticConfig(c);
    }
}
