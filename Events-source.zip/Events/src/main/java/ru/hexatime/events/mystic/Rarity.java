package ru.hexatime.events.mystic;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Ровно четыре редкости из ТЗ. */
public enum Rarity {
    COMMON("common", "Обычный", "#FFFFFF"),
    RARE("rare", "Редкий", "#35C759"),
    EPIC("epic", "Эпический", "#B45BDF"),
    LEGENDARY("legendary", "Легендарный", "#FFD43B");

    private final String id;
    private final String title;
    private final TextColor color;

    Rarity(String id, String title, String hex) {
        this.id = id;
        this.title = title;
        this.color = TextColor.fromHexString(hex);
    }

    public String id() {
        return id;
    }

    public TextColor color() {
        return color;
    }

    public String displayText() {
        return title + " Mystic";
    }

    /** Название в цвете редкости (без курсива). */
    public Component component() {
        return Component.text(displayText(), color).decoration(TextDecoration.ITALIC, false);
    }

    /** Принимает common/rare/epic/legendary и русские названия. */
    public static Rarity parse(String s) {
        if (s == null) {
            return null;
        }
        String v = s.toLowerCase(Locale.ROOT);
        for (Rarity r : values()) {
            if (r.id.equals(v) || r.title.toLowerCase(Locale.ROOT).equals(v)) {
                return r;
            }
        }
        return null;
    }

    public static List<String> ids() {
        return Arrays.stream(values()).map(Rarity::id).toList();
    }
}
