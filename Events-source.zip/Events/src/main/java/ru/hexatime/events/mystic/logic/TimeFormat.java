package ru.hexatime.events.mystic.logic;

public final class TimeFormat {

    private TimeFormat() {
    }

    /** 75000 → "1:15", 3_725_000 → "1:02:05". Округляет вверх до секунды. */
    public static String format(long ms) {
        long total = ms <= 0 ? 0 : (ms + 999) / 1000;
        long h = total / 3600;
        long m = (total % 3600) / 60;
        long s = total % 60;
        return h > 0 ? String.format("%d:%02d:%02d", h, m, s) : String.format("%d:%02d", m, s);
    }
}
